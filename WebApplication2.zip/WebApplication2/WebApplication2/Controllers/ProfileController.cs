using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ProfileController : Controller
    {
        [HttpGet]
        public IActionResult Input()
        {
            ViewData["Title"] = "���� ������ �������";
            return View();
        }

        [HttpPost]
        public IActionResult Input(ProfileViewModel model)
        {
            if (ModelState.IsValid)
            {
                HttpContext.Session.SetString("ProfileFirstName", model.FirstName ?? "");
                HttpContext.Session.SetString("ProfileLastName", model.LastName ?? "");
                HttpContext.Session.SetString("ProfileEmail", model.Email ?? "");
                HttpContext.Session.SetInt32("ProfileAge", model.Age ?? 0);

                return RedirectToAction("Display");
            }
            return View(model);
        }

        public IActionResult Display()
        {
            ViewData["Title"] = "������ �������";

            var model = new ProfileViewModel
            {
                FirstName = HttpContext.Session.GetString("ProfileFirstName"),
                LastName = HttpContext.Session.GetString("ProfileLastName"),
                Email = HttpContext.Session.GetString("ProfileEmail"),
                Age = HttpContext.Session.GetInt32("ProfileAge")
            };

            return View(model);
        }
    }
}