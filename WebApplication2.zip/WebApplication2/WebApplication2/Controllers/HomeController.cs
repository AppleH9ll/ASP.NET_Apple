using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewData["Title"] = "�������";
            return View();
        }

        public IActionResult About()
        {
            ViewData["Title"] = "� ���";
            return View();
        }
    }
}